<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Include functions with proper path handling
$root_path = dirname(__DIR__);
require_once $root_path . '/config/database.php';
require_once $root_path . '/includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

// Better URL parsing for XAMPP
$request_uri = $_SERVER['REQUEST_URI'];
$script_name = $_SERVER['SCRIPT_NAME'];
$path_info = str_replace(dirname($script_name), '', $request_uri);
$path_info = str_replace(basename($script_name), '', $path_info);
$request = array_filter(explode('/', trim($path_info, '/')));
$request = array_values($request); // Re-index array

// Handle OPTIONS request for CORS
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    switch ($method) {
        case 'GET':
            if (empty($request[0])) {
                // Get all shipments with optional search and filter
                $search = $_GET['search'] ?? '';
                $cabang_tujuan = $_GET['cabang_tujuan'] ?? '';
                
                // Debug logging
                error_log("API GET request - Search: '$search', Branch: '$cabang_tujuan'");
                
                try {
                    $shipments = getShipments($search, $cabang_tujuan);
                    
                    // Ensure we return an array
                    if (!is_array($shipments)) {
                        $shipments = [];
                    }
                    
                    error_log("API returning " . count($shipments) . " shipments");
                    echo json_encode($shipments);
                } catch (Exception $e) {
                    error_log("API Error in getShipments: " . $e->getMessage());
                    http_response_code(500);
                    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
                }
            } else {
                // Get specific shipment
                $id = intval($request[0]);
                $shipment = getShipmentById($id);
                
                if ($shipment) {
                    echo json_encode($shipment);
                } else {
                    http_response_code(404);
                    echo json_encode(['error' => 'Pengiriman tidak ditemukan']);
                }
            }
            break;
            
        case 'POST':
            // Create new shipment
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input) {
                http_response_code(400);
                echo json_encode(['error' => 'Data tidak valid']);
                break;
            }
            
            // Validate required fields
            $required = ['no_polisi', 'no_segel', 'nama_driver', 'nama_staff', 'cabang_tujuan'];
            foreach ($required as $field) {
                if (empty($input[$field])) {
                    http_response_code(400);
                    echo json_encode(['error' => "Field $field harus diisi"]);
                    exit;
                }
            }
            
            $result = createShipment($input);
            
            if ($result['success']) {
                http_response_code(201);
                echo json_encode(['message' => 'Pengiriman berhasil disimpan', 'id' => $result['id']]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Gagal menyimpan pengiriman: ' . $result['error']]);
            }
            break;
            
        case 'PUT':
            // Update shipment
            if (empty($request[0])) {
                http_response_code(400);
                echo json_encode(['error' => 'ID pengiriman diperlukan']);
                break;
            }
            
            $id = intval($request[0]);
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!$input) {
                http_response_code(400);
                echo json_encode(['error' => 'Data tidak valid']);
                break;
            }
            
            $result = updateShipment($id, $input);
            
            if ($result['success']) {
                echo json_encode(['message' => 'Pengiriman berhasil diperbarui']);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Gagal memperbarui pengiriman: ' . $result['error']]);
            }
            break;
            
        case 'DELETE':
            // Delete shipment
            if (empty($request[0])) {
                http_response_code(400);
                echo json_encode(['error' => 'ID pengiriman diperlukan']);
                break;
            }
            
            $id = intval($request[0]);
            $result = deleteShipment($id);
            
            if ($result['success']) {
                echo json_encode(['message' => 'Pengiriman berhasil dihapus']);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Gagal menghapus pengiriman: ' . $result['error']]);
            }
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method tidak diizinkan']);
            break;
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
?>