<?php
session_start();

// Simple authentication system
class Auth {
    private static $users = [
        'admin' => [
            'password' => 'admin123',
            'name' => 'Administrator',
            'role' => 'admin'
        ],
        'staff' => [
            'password' => 'staff123',
            'name' => 'Staff Pengiriman',
            'role' => 'staff'
        ],
        'operator' => [
            'password' => 'operator123',
            'name' => 'Operator',
            'role' => 'operator'
        ]
    ];
    
    public static function login($username, $password) {
        if (isset(self::$users[$username]) && self::$users[$username]['password'] === $password) {
            $_SESSION['user_logged_in'] = true;
            $_SESSION['username'] = $username;
            $_SESSION['user_name'] = self::$users[$username]['name'];
            $_SESSION['user_role'] = self::$users[$username]['role'];
            $_SESSION['login_time'] = time();
            return true;
        }
        return false;
    }
    
    public static function logout() {
        session_destroy();
        return true;
    }
    
    public static function isLoggedIn() {
        return isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true;
    }
    
    public static function requireLogin() {
        if (!self::isLoggedIn()) {
            header('Location: login.php');
            exit();
        }
    }
    
    public static function getUser() {
        if (self::isLoggedIn()) {
            return [
                'username' => $_SESSION['username'],
                'name' => $_SESSION['user_name'],
                'role' => $_SESSION['user_role'],
                'login_time' => $_SESSION['login_time']
            ];
        }
        return null;
    }
    
    public static function hasRole($role) {
        return self::isLoggedIn() && $_SESSION['user_role'] === $role;
    }
}
?>