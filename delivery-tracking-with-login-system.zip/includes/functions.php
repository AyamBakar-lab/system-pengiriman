<?php
// Database connection is already established in database.php
// This file contains all the CRUD functions

// Function to get all shipments with search and filter
function getShipments($search = '', $cabang_tujuan = '') {
    global $pdo;
    
    try {
        $sql = "SELECT s.*, 
                       COUNT(si.id) as total_items,
                       GROUP_CONCAT(CONCAT(si.nama_barang, '|', si.no_dokumen, '|', si.tanggal_kirim, '|', si.jumlah_barang, '|', IFNULL(si.catatan, '')) SEPARATOR '|||') as items_data
                FROM shipments s 
                LEFT JOIN shipment_items si ON s.id = si.shipment_id 
                WHERE 1=1";
        
        $params = [];
        
        // Enhanced search - include ID form, document number and other fields
        if (!empty($search)) {
            $sql .= " AND (s.id_form LIKE ? OR s.no_dokumen LIKE ? OR s.no_polisi LIKE ? OR s.nama_driver LIKE ? OR s.nama_co_driver LIKE ? OR s.nama_staff LIKE ? OR s.cabang_tujuan LIKE ? OR s.no_segel LIKE ?)";
            $searchParam = "%$search%";
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
            $params[] = $searchParam;
        }
        
        if (!empty($cabang_tujuan) && $cabang_tujuan !== 'semua') {
            $sql .= " AND s.cabang_tujuan = ?";
            $params[] = $cabang_tujuan;
        }
        
        $sql .= " GROUP BY s.id ORDER BY s.created_at DESC";
        
        error_log("SQL Query: $sql");
        error_log("Params: " . json_encode($params));
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        $shipments = $stmt->fetchAll();
        error_log("Found " . count($shipments) . " shipments");
        
        // Parse items data
        foreach ($shipments as &$shipment) {
            $shipment['items'] = [];
            if (!empty($shipment['items_data'])) {
                $items = explode('|||', $shipment['items_data']);
                foreach ($items as $item) {
                    if (trim($item)) { // Only process non-empty items
                        $itemData = explode('|', $item);
                        if (count($itemData) >= 4) {
                            $shipment['items'][] = [
                                'nama_barang' => $itemData[0],
                                'no_dokumen' => $itemData[1],
                                'tanggal_kirim' => $itemData[2],
                                'jumlah_barang' => (int)$itemData[3],
                                'catatan' => $itemData[4] ?? ''
                            ];
                        }
                    }
                }
            }
            unset($shipment['items_data']);
            
            // Ensure total_items is properly set
            if (empty($shipment['total_items'])) {
                $shipment['total_items'] = count($shipment['items']);
            }
        }
        
        return $shipments;
        
    } catch (PDOException $e) {
        error_log("Database error in getShipments: " . $e->getMessage());
        throw new Exception("Database query failed: " . $e->getMessage());
    }
}

// Function to get single shipment with items
function getShipmentById($id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM shipments WHERE id = ?");
    $stmt->execute([$id]);
    $shipment = $stmt->fetch();
    
    if ($shipment) {
        $stmt = $pdo->prepare("SELECT * FROM shipment_items WHERE shipment_id = ?");
        $stmt->execute([$id]);
        $shipment['items'] = $stmt->fetchAll();
    }
    
    return $shipment;
}

// Function to create new shipment
function createShipment($data) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Generate auto document number
        $now = new DateTime();
        $dateStr = $now->format('Ymd');
        $timestamp = $now->format('His');
        $autoDocNumber = "DOK-{$dateStr}-{$timestamp}";
        
        // Insert shipment
        $stmt = $pdo->prepare("INSERT INTO shipments (id_form, no_dokumen, no_polisi, no_segel, nama_driver, nama_co_driver, nama_staff, cabang_tujuan, catatan_pengiriman) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['id_form'],
            $autoDocNumber,
            $data['no_polisi'],
            $data['no_segel'],
            $data['nama_driver'],
            $data['nama_co_driver'] ?? '',
            $data['nama_staff'],
            $data['cabang_tujuan'],
            $data['catatan_pengiriman'] ?? ''
        ]);
        
        $shipmentId = $pdo->lastInsertId();
        
        // Insert items
        if (!empty($data['items'])) {
            $stmt = $pdo->prepare("INSERT INTO shipment_items (shipment_id, nama_barang, no_dokumen, tanggal_kirim, jumlah_barang, catatan) VALUES (?, ?, ?, ?, ?, ?)");
            
            foreach ($data['items'] as $item) {
                $stmt->execute([
                    $shipmentId,
                    $item['nama_barang'],
                    $item['no_dokumen'],
                    $item['tanggal_kirim'],
                    $item['jumlah_barang'],
                    $item['catatan'] ?? ''
                ]);
            }
        }
        
        $pdo->commit();
        return ['success' => true, 'id' => $shipmentId];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// Function to update shipment
function updateShipment($id, $data) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Generate auto document number if not provided
        $docNumber = $data['no_dokumen'] ?? '';
        if (empty($docNumber)) {
            $now = new DateTime();
            $dateStr = $now->format('Ymd');
            $timestamp = $now->format('His');
            $docNumber = "DOK-{$dateStr}-{$timestamp}";
        }
        
        // Update shipment
        $stmt = $pdo->prepare("UPDATE shipments SET id_form=?, no_dokumen=?, no_polisi=?, no_segel=?, nama_driver=?, nama_co_driver=?, nama_staff=?, cabang_tujuan=?, catatan_pengiriman=? WHERE id=?");
        $stmt->execute([
            $data['id_form'],
            $docNumber,
            $data['no_polisi'],
            $data['no_segel'],
            $data['nama_driver'],
            $data['nama_co_driver'] ?? '',
            $data['nama_staff'],
            $data['cabang_tujuan'],
            $data['catatan_pengiriman'] ?? '',
            $id
        ]);
        
        // Delete existing items
        $stmt = $pdo->prepare("DELETE FROM shipment_items WHERE shipment_id = ?");
        $stmt->execute([$id]);
        
        // Insert new items
        if (!empty($data['items'])) {
            $stmt = $pdo->prepare("INSERT INTO shipment_items (shipment_id, nama_barang, no_dokumen, tanggal_kirim, jumlah_barang, catatan) VALUES (?, ?, ?, ?, ?, ?)");
            
            foreach ($data['items'] as $item) {
                $stmt->execute([
                    $id,
                    $item['nama_barang'],
                    $item['no_dokumen'],
                    $item['tanggal_kirim'],
                    $item['jumlah_barang'],
                    $item['catatan'] ?? ''
                ]);
            }
        }
        
        $pdo->commit();
        return ['success' => true];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// Function to delete shipment
function deleteShipment($id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM shipments WHERE id = ?");
        $stmt->execute([$id]);
        return ['success' => true];
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// Function to format Indonesian date
function formatIndonesianDate($date) {
    $months = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    
    $timestamp = strtotime($date);
    $day = date('d', $timestamp);
    $month = $months[(int)date('m', $timestamp)];
    $year = date('Y', $timestamp);
    
    return "$day $month $year";
}

// Function to get branch color
function getBranchColor($branch) {
    $colors = [
        'jakarta' => 'bg-blue-100 text-blue-800',
        'bandung' => 'bg-purple-100 text-purple-800',
        'surabaya' => 'bg-green-100 text-green-800',
        'medan' => 'bg-orange-100 text-orange-800',
        'makassar' => 'bg-pink-100 text-pink-800'
    ];
    
    return $colors[$branch] ?? 'bg-gray-100 text-gray-800';
}
?>