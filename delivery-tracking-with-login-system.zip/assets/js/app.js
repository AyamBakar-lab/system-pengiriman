// Main JavaScript for Delivery Tracking Application

class DeliveryApp {
    constructor() {
        this.currentTab = 'form';
        this.shipments = [];
        this.editingId = null;
        this.items = [this.createEmptyItem()];
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadShipments();
        this.generateFormId(); // Generate initial form ID
        this.generateDocumentNumber(); // Generate initial document number
    }
    
    getApiUrl(endpoint) {
        // Try multiple API endpoint options
        if (endpoint === 'api/shipments.php') {
            // Return array of possible endpoints to try
            return [
                './api/shipments.php',
                'api/shipments.php',
                './direct-api-test.php'
            ];
        }
        return './' + endpoint;
    }
    
    async fetchWithFallback(endpoints, options = {}) {
        if (typeof endpoints === 'string') {
            return fetch(endpoints, options);
        }
        
        // Try each endpoint until one works
        let lastError;
        for (const endpoint of endpoints) {
            try {
                console.log('Trying endpoint:', endpoint);
                const response = await fetch(endpoint, options);
                if (response.ok) {
                    console.log('Success with endpoint:', endpoint);
                    return response;
                }
                lastError = new Error(`HTTP ${response.status}: ${response.statusText}`);
            } catch (error) {
                console.log('Failed endpoint:', endpoint, error.message);
                lastError = error;
            }
        }
        throw lastError;
    }
    
    bindEvents() {
        // Tab navigation
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });
        
        // Form submission
        document.getElementById('shipmentForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveShipment();
        });
        
        // Add item button
        document.getElementById('addItemBtn').addEventListener('click', () => {
            this.addItem();
        });
        
        // Generate form ID button
        document.getElementById('generateFormIdBtn').addEventListener('click', () => {
            this.generateFormId();
        });
        

        
        // Search functionality with debouncing
        let searchTimeout;
        document.getElementById('searchInput').addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                this.loadShipments();
            }, 500); // Delay 500ms untuk mengurangi API calls
        });
        
        // Filter functionality
        document.getElementById('branchFilter').addEventListener('change', (e) => {
            this.loadShipments();
        });
        
        // Cancel edit button
        document.getElementById('cancelEdit').addEventListener('click', () => {
            this.cancelEdit();
        });
        
        // Form ID search functionality
        document.getElementById('searchFormBtn').addEventListener('click', () => {
            this.searchFormById();
        });
        
        document.getElementById('formIdSearch').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.searchFormById();
            }
        });
    }
    
    switchTab(tabName) {
        this.currentTab = tabName;
        
        // Update tab appearance
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        
        // Show/hide content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(`${tabName}Tab`).classList.remove('hidden');
        
        if (tabName === 'list') {
            this.loadShipments();
        }
    }
    
    generateFormId() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const timestamp = Date.now().toString().slice(-4);
        
        const formId = `FORM-${year}${month}${day}-${timestamp}`;
        
        document.getElementById('id_form').value = formId;
        
        // Show notification
        this.showNotification('🆔 ID Form', `ID form baru: ${formId}`, 'info');
        
        return formId;
    }
    

    
    createEmptyItem() {
        return {
            id: Date.now() + Math.random(),
            nama_barang: '',
            no_dokumen: '',
            tanggal_kirim: new Date().toISOString().split('T')[0],
            jumlah_barang: 1,
            catatan: ''
        };
    }
    
    addItem() {
        this.items.push(this.createEmptyItem());
        this.renderItems();
    }
    
    removeItem(itemId) {
        if (this.items.length > 1) {
            this.items = this.items.filter(item => item.id !== itemId);
            this.renderItems();
        }
    }
    
    updateItem(itemId, field, value) {
        const item = this.items.find(item => item.id === itemId);
        if (item) {
            item[field] = value;
        }
    }
    
    renderItems() {
        const tbody = document.getElementById('itemsTableBody');
        tbody.innerHTML = '';
        
        this.items.forEach((item, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="text-center">${index + 1}</td>
                <td>
                    <input type="text" class="form-input" placeholder="Nama barang" 
                           value="${item.nama_barang}" 
                           onchange="app.updateItem(${item.id}, 'nama_barang', this.value)">
                </td>
                <td>
                    <input type="text" class="form-input" placeholder="No. dokumen" 
                           value="${item.no_dokumen}" 
                           onchange="app.updateItem(${item.id}, 'no_dokumen', this.value)">
                </td>
                <td>
                    <input type="date" class="form-input" 
                           value="${item.tanggal_kirim}" 
                           onchange="app.updateItem(${item.id}, 'tanggal_kirim', this.value)">
                </td>
                <td>
                    <input type="number" class="form-input" min="1" 
                           value="${item.jumlah_barang}" 
                           onchange="app.updateItem(${item.id}, 'jumlah_barang', parseInt(this.value) || 1)">
                </td>
                <td>
                    <input type="text" class="form-input" placeholder="Catatan" 
                           value="${item.catatan}" 
                           onchange="app.updateItem(${item.id}, 'catatan', this.value)">
                </td>
                <td class="text-center">
                    ${this.items.length > 1 ? `
                        <button type="button" class="btn btn-danger btn-sm" 
                                onclick="app.removeItem(${item.id})" title="Hapus">
                            🗑️
                        </button>
                    ` : ''}
                </td>
            `;
            tbody.appendChild(row);
        });
    }
    
    async saveShipment() {
        this.showNotification('📋 Mempersiapkan Data', 'Memeriksa kelengkapan data pengiriman...', 'info');
        
        const formData = new FormData(document.getElementById('shipmentForm'));
        const shipmentData = Object.fromEntries(formData.entries());
        
        // Validate items
        const validItems = this.items.filter(item => 
            item.nama_barang.trim() !== '' && 
            item.jumlah_barang > 0
        );
        
        if (validItems.length === 0) {
            this.showNotification('⚠️ Data Tidak Lengkap', 'Pastikan minimal ada 1 barang dengan nama yang terisi', 'error');
            return;
        }
        
        this.showNotification('✅ Data Valid', `${validItems.length} barang siap untuk disimpan`, 'success');
        
        const data = {
            ...shipmentData,
            items: validItems
        };
        
        try {
            this.showNotification('💾 Menyimpan...', 'Sedang menyimpan data pengiriman ke database', 'info');
            
            const url = this.editingId ? 
                this.getApiUrl(`api/shipments.php/${this.editingId}`) : 
                this.getApiUrl('api/shipments.php');
            
            const method = this.editingId ? 'PUT' : 'POST';
            
            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (response.ok) {
                this.showNotification('✅ Berhasil Disimpan', result.message, 'success');
                this.resetForm();
                this.loadShipments();
                this.switchTab('list');
            } else {
                this.showNotification('❌ Gagal Menyimpan', result.error, 'error');
            }
            
        } catch (error) {
            this.showNotification('❌ Error', 'Terjadi kesalahan saat menyimpan data', 'error');
            console.error('Error:', error);
        }
    }
    
    resetForm() {
        document.getElementById('shipmentForm').reset();
        this.items = [this.createEmptyItem()];
        this.renderItems();
        this.editingId = null;
        document.getElementById('formTitle').textContent = 'Form Pencatatan Pengiriman Barang';
        document.getElementById('submitBtn').innerHTML = '💾 Simpan Pengiriman';
        document.getElementById('cancelEdit').classList.add('hidden');
        
        // Generate new IDs
        this.generateFormId();
        this.generateDocumentNumber();
    }
    
    async loadShipments() {
        try {
            const search = document.getElementById('searchInput')?.value || '';
            const branch = document.getElementById('branchFilter')?.value || '';
            
            // Show loading indicator
            const container = document.getElementById('shipmentsList');
            container.innerHTML = `
                <div class="loading">
                    <div class="spinner"></div>
                    ${search ? 'Mencari pengiriman...' : 'Memuat data pengiriman...'}
                </div>
            `;
            
            let endpoints = this.getApiUrl('api/shipments.php');
            const params = new URLSearchParams();
            
            if (search.trim()) {
                params.append('search', search.trim());
            }
            if (branch && branch !== 'semua') {
                params.append('cabang_tujuan', branch);
            }
            
            const queryString = params.toString();
            if (queryString) {
                endpoints = endpoints.map(url => url + '?' + queryString);
            }
            
            console.log('Trying endpoints:', endpoints);
            
            const response = await this.fetchWithFallback(endpoints);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const result = await response.json();
            console.log('Received result:', result);
            
            let shipments = [];
            
            // Handle different response formats
            if (Array.isArray(result)) {
                shipments = result;
            } else if (result.data && Array.isArray(result.data)) {
                shipments = result.data; // Direct API test format
            } else if (result.error) {
                throw new Error(result.error);
            } else if (result.message) {
                throw new Error(result.message);
            } else {
                console.error('Invalid response format:', result);
                shipments = [];
            }
            
            this.shipments = shipments;
            
            this.renderShipments();
            
            // Show search result notification
            if (search.trim()) {
                this.showNotification(
                    '🔍 Hasil Pencarian', 
                    `Ditemukan ${this.shipments.length} pengiriman untuk "${search}"`, 
                    this.shipments.length > 0 ? 'success' : 'warning'
                );
            }
            
        } catch (error) {
            console.error('Load shipments error:', error);
            this.showNotification('❌ Error', `Gagal memuat data: ${error.message}`, 'error');
            this.shipments = [];
            this.renderShipments();
        }
    }
    
    renderShipments() {
        const container = document.getElementById('shipmentsList');
        
        if (this.shipments.length === 0) {
            container.innerHTML = `
                <div class="text-center" style="padding: 40px; color: #64748b;">
                    <div style="font-size: 48px; margin-bottom: 16px;">📦</div>
                    <h3>Belum Ada Data Pengiriman</h3>
                    <p>Silakan tambahkan pengiriman baru melalui form.</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = this.shipments.map(shipment => `
            <div class="shipment-item">
                <div class="shipment-header">
                    <div class="shipment-info">
                        <div class="shipment-title">🆔 ${shipment.id_form || 'FORM-AUTO'} | 📄 ${shipment.no_dokumen || 'DOK-AUTO'} | 🚛 ${shipment.no_polisi} - ${shipment.no_segel}</div>
                        <div class="shipment-meta">
                            <span class="meta-item">
                                <span class="meta-label">Driver:</span> ${shipment.nama_driver}
                                ${shipment.nama_co_driver ? ` & ${shipment.nama_co_driver}` : ''}
                            </span>
                            <span class="meta-item">
                                <span class="meta-label">Staff:</span> ${shipment.nama_staff}
                            </span>
                            <span class="meta-item">
                                <span class="meta-label">Tujuan:</span> 
                                <span class="badge badge-${shipment.cabang_tujuan}">${shipment.cabang_tujuan.toUpperCase()}</span>
                            </span>
                            <span class="meta-item">
                                <span class="meta-label">Tanggal:</span> ${this.formatDate(shipment.created_at)}
                            </span>
                        </div>
                        ${shipment.catatan_pengiriman ? `
                            <div class="meta-item">
                                <span class="meta-label">Catatan:</span> ${shipment.catatan_pengiriman}
                            </div>
                        ` : ''}
                        <div class="meta-item">
                            <span class="meta-label">Total Barang:</span> ${shipment.total_items} item
                        </div>
                    </div>
                    <div class="shipment-actions">
                        <button class="btn btn-primary btn-sm" onclick="app.viewShipment(${shipment.id})" title="Lihat Detail">
                            👁️
                        </button>
                        <button class="btn btn-warning btn-sm" onclick="app.editShipment(${shipment.id})" title="Edit">
                            ✏️
                        </button>
                        <button class="btn btn-success btn-sm" onclick="app.printShipment(${shipment.id})" title="Print Surat Jalan">
                            🖨️
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="app.deleteShipment(${shipment.id})" title="Hapus">
                            🗑️
                        </button>
                    </div>
                </div>
                
                ${shipment.items && shipment.items.length > 0 ? `
                    <div class="items-section" style="margin-top: 15px;">
                        <strong>Daftar Barang yang Dikirim:</strong>
                        <div class="items-table-container" style="margin-top: 10px; overflow-x: auto;">
                            <table class="items-table" style="width: 100%; border-collapse: collapse; border: 1px solid #e2e8f0; font-size: 14px;">
                                <thead>
                                    <tr style="background: #f1f5f9; font-weight: bold;">
                                        <th style="border: 1px solid #e2e8f0; padding: 8px; text-align: left; width: 40px;">No</th>
                                        <th style="border: 1px solid #e2e8f0; padding: 8px; text-align: left;">Nama Barang</th>
                                        <th style="border: 1px solid #e2e8f0; padding: 8px; text-align: left; width: 120px;">No. Dokumen</th>
                                        <th style="border: 1px solid #e2e8f0; padding: 8px; text-align: left; width: 100px;">Tanggal Kirim</th>
                                        <th style="border: 1px solid #e2e8f0; padding: 8px; text-align: center; width: 80px;">Jumlah</th>
                                        <th style="border: 1px solid #e2e8f0; padding: 8px; text-align: left;">Catatan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${shipment.items.map((item, index) => `
                                        <tr style="background: ${index % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                                            <td style="border: 1px solid #e2e8f0; padding: 8px; text-align: center; font-weight: bold; color: #64748b;">${index + 1}</td>
                                            <td style="border: 1px solid #e2e8f0; padding: 8px; font-weight: 500;">${item.nama_barang}</td>
                                            <td style="border: 1px solid #e2e8f0; padding: 8px; color: #64748b; font-size: 12px;">${item.no_dokumen}</td>
                                            <td style="border: 1px solid #e2e8f0; padding: 8px; color: #64748b; font-size: 12px;">${this.formatDate(item.tanggal_kirim)}</td>
                                            <td style="border: 1px solid #e2e8f0; padding: 8px; text-align: center;">
                                                <span style="background: #3b82f6; color: white; padding: 2px 6px; border-radius: 12px; font-size: 12px; font-weight: bold;">
                                                    ${item.jumlah_barang}
                                                </span>
                                            </td>
                                            <td style="border: 1px solid #e2e8f0; padding: 8px; color: #64748b; font-style: italic;">${item.catatan || '-'}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                                <tfoot>
                                    <tr style="background: #f1f5f9; font-weight: bold;">
                                        <td colspan="4" style="border: 1px solid #e2e8f0; padding: 8px; text-align: right;">Total Items:</td>
                                        <td style="border: 1px solid #e2e8f0; padding: 8px; text-align: center; color: #059669;">
                                            ${shipment.items.length}
                                        </td>
                                        <td style="border: 1px solid #e2e8f0; padding: 8px;">
                                            Total Barang: ${shipment.items.reduce((sum, item) => sum + parseInt(item.jumlah_barang), 0)} pcs
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                ` : `
                    <div class="no-items" style="margin-top: 15px; padding: 20px; background: #fef3cd; border: 1px solid #fbbf24; border-radius: 6px; text-align: center;">
                        <span style="color: #92400e;">⚠️ Tidak ada barang yang tercatat untuk pengiriman ini</span>
                    </div>
                `}
            </div>
        `).join('');
    }
    
    async editShipment(id) {
        try {
            const response = await fetch(this.getApiUrl(`api/shipments.php/${id}`));
            const shipment = await response.json();
            
            if (response.ok) {
                this.editingId = id;
                
                // Fill form with shipment data
                document.getElementById('id_form').value = shipment.id_form || '';
                document.getElementById('no_polisi').value = shipment.no_polisi;
                document.getElementById('no_segel').value = shipment.no_segel;
                document.getElementById('nama_driver').value = shipment.nama_driver;
                document.getElementById('nama_co_driver').value = shipment.nama_co_driver || '';
                document.getElementById('nama_staff').value = shipment.nama_staff;
                document.getElementById('cabang_tujuan').value = shipment.cabang_tujuan;
                document.getElementById('catatan_pengiriman').value = shipment.catatan_pengiriman || '';
                
                // Fill items
                this.items = shipment.items.map(item => ({
                    id: Date.now() + Math.random(),
                    nama_barang: item.nama_barang,
                    no_dokumen: item.no_dokumen,
                    tanggal_kirim: item.tanggal_kirim.split(' ')[0], // Extract date part
                    jumlah_barang: item.jumlah_barang,
                    catatan: item.catatan || ''
                }));
                
                this.renderItems();
                
                // Update form UI
                document.getElementById('formTitle').textContent = `Edit Pengiriman - ${shipment.no_polisi}`;
                document.getElementById('submitBtn').innerHTML = '💾 Simpan Perubahan';
                document.getElementById('cancelEdit').classList.remove('hidden');
                
                this.switchTab('form');
                
            } else {
                this.showNotification('❌ Error', shipment.error, 'error');
            }
            
        } catch (error) {
            this.showNotification('❌ Error', 'Gagal memuat data pengiriman', 'error');
            console.error('Error:', error);
        }
    }
    
    cancelEdit() {
        this.resetForm();
    }
    
    async deleteShipment(id) {
        if (!confirm('Apakah Anda yakin ingin menghapus data pengiriman ini? Tindakan ini tidak dapat dibatalkan.')) {
            return;
        }
        
        try {
            const response = await fetch(this.getApiUrl(`api/shipments.php/${id}`), {
                method: 'DELETE'
            });
            
            const result = await response.json();
            
            if (response.ok) {
                this.showNotification('✅ Berhasil', result.message, 'success');
                this.loadShipments();
            } else {
                this.showNotification('❌ Error', result.error, 'error');
            }
            
        } catch (error) {
            this.showNotification('❌ Error', 'Gagal menghapus data pengiriman', 'error');
            console.error('Error:', error);
        }
    }
    
    async viewShipment(id) {
        try {
            const response = await fetch(this.getApiUrl(`api/shipments.php/${id}`));
            const shipment = await response.json();
            
            if (response.ok) {
                this.showShipmentModal(shipment);
            } else {
                this.showNotification('❌ Error', shipment.error, 'error');
            }
            
        } catch (error) {
            this.showNotification('❌ Error', 'Gagal memuat detail pengiriman', 'error');
            console.error('Error:', error);
        }
    }
    
    showShipmentModal(shipment) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">Detail Pengiriman - ${shipment.no_polisi}</h2>
                </div>
                <div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                        <div>
                            <strong>No. Polisi:</strong> ${shipment.no_polisi}<br>
                            <strong>No. Segel:</strong> ${shipment.no_segel}<br>
                            <strong>Driver:</strong> ${shipment.nama_driver}<br>
                            ${shipment.nama_co_driver ? `<strong>Co-Driver:</strong> ${shipment.nama_co_driver}<br>` : ''}
                        </div>
                        <div>
                            <strong>Staff:</strong> ${shipment.nama_staff}<br>
                            <strong>Cabang Tujuan:</strong> ${shipment.cabang_tujuan.toUpperCase()}<br>
                            <strong>Tanggal:</strong> ${this.formatDate(shipment.created_at)}<br>
                        </div>
                    </div>
                    
                    ${shipment.catatan_pengiriman ? `
                        <div style="margin-bottom: 20px;">
                            <strong>Catatan Pengiriman:</strong><br>
                            <div style="background: #f8fafc; padding: 10px; border-radius: 4px; margin-top: 5px;">
                                ${shipment.catatan_pengiriman}
                            </div>
                        </div>
                    ` : ''}
                    
                    <div>
                        <strong>Daftar Barang:</strong>
                        <table class="items-table" style="margin-top: 10px;">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Barang</th>
                                    <th>No. Dokumen</th>
                                    <th>Tanggal Kirim</th>
                                    <th>Jumlah</th>
                                    <th>Catatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${shipment.items.map((item, index) => `
                                    <tr>
                                        <td>${index + 1}</td>
                                        <td>${item.nama_barang}</td>
                                        <td>${item.no_dokumen}</td>
                                        <td>${this.formatDate(item.tanggal_kirim)}</td>
                                        <td>${item.jumlah_barang}</td>
                                        <td>${item.catatan || '-'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="btn btn-outline" onclick="this.closest('.modal-overlay').remove()">Tutup</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close modal when clicking outside
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
    
    async printShipment(id) {
        try {
            const response = await fetch(this.getApiUrl(`api/shipments.php/${id}`));
            const shipment = await response.json();
            
            if (response.ok) {
                const printWindow = window.open('', '_blank');
                const printContent = `
                    <!DOCTYPE html>
                    <html>
                        <head>
                            <title>Surat Jalan - ${shipment.no_polisi}</title>
                            <style>
                                body { font-family: Arial, sans-serif; margin: 20px; }
                                .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
                                .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
                                .info-item { margin-bottom: 10px; }
                                .label { font-weight: bold; }
                                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                                th, td { border: 1px solid #000; padding: 8px; text-align: left; }
                                th { background-color: #f0f0f0; }
                                .footer { margin-top: 30px; display: grid; grid-template-columns: 1fr 1fr; gap: 50px; }
                                .signature { text-align: center; }
                                .signature-line { border-top: 1px solid #000; margin-top: 50px; padding-top: 5px; }
                                @media print { body { margin: 0; } }
                            </style>
                        </head>
                        <body>
                            <div class="header">
                                <h1>SURAT JALAN</h1>
                                <p>Sistem Pencatatan Pengiriman Barang</p>
                            </div>
                            
                            <div class="info-grid">
                                <div>
                                    <div class="info-item">
                                        <span class="label">No. Polisi:</span> ${shipment.no_polisi}
                                    </div>
                                    <div class="info-item">
                                        <span class="label">No. Segel:</span> ${shipment.no_segel}
                                    </div>
                                    <div class="info-item">
                                        <span class="label">Driver:</span> ${shipment.nama_driver}
                                    </div>
                                    ${shipment.nama_co_driver ? `<div class="info-item"><span class="label">Co-Driver:</span> ${shipment.nama_co_driver}</div>` : ''}
                                </div>
                                <div>
                                    <div class="info-item">
                                        <span class="label">Staff:</span> ${shipment.nama_staff}
                                    </div>
                                    <div class="info-item">
                                        <span class="label">Cabang Tujuan:</span> ${shipment.cabang_tujuan.toUpperCase()}
                                    </div>
                                    <div class="info-item">
                                        <span class="label">Tanggal:</span> ${this.formatDate(shipment.created_at)}
                                    </div>
                                </div>
                            </div>

                            ${shipment.catatan_pengiriman ? `
                                <div style="margin-bottom: 20px;">
                                    <div class="label">Catatan Pengiriman:</div>
                                    <p style="border: 1px solid #ccc; padding: 10px; background-color: #f9f9f9;">${shipment.catatan_pengiriman}</p>
                                </div>
                            ` : ''}

                            <table>
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Barang</th>
                                        <th>No. Dokumen</th>
                                        <th>Tanggal Kirim</th>
                                        <th>Jumlah</th>
                                        <th>Catatan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${shipment.items.map((item, index) => `
                                        <tr>
                                            <td>${index + 1}</td>
                                            <td>${item.nama_barang}</td>
                                            <td>${item.no_dokumen}</td>
                                            <td>${this.formatDate(item.tanggal_kirim)}</td>
                                            <td>${item.jumlah_barang}</td>
                                            <td>${item.catatan || '-'}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>

                            <div class="footer">
                                <div class="signature">
                                    <div class="signature-line">
                                        Pengirim
                                    </div>
                                </div>
                                <div class="signature">
                                    <div class="signature-line">
                                        Penerima
                                    </div>
                                </div>
                            </div>
                        </body>
                    </html>
                `;
                
                printWindow.document.write(printContent);
                printWindow.document.close();
                printWindow.print();
                
            } else {
                this.showNotification('❌ Error', shipment.error, 'error');
            }
            
        } catch (error) {
            this.showNotification('❌ Error', 'Gagal memuat data untuk print', 'error');
            console.error('Error:', error);
        }
    }
    
    // Search and filter methods removed - now handled directly in loadShipments()
    
    formatDate(dateString) {
        const options = { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        return new Date(dateString).toLocaleDateString('id-ID', options);
    }
    
    async searchFormById() {
        const formId = document.getElementById('formIdSearch').value.trim();
        
        if (!formId) {
            this.showNotification('Peringatan', 'Silakan masukkan ID Form yang ingin dicari', 'warning');
            return;
        }
        
        try {
            const response = await this.fetchWithFallback([
                this.getApiUrl(`get-form-details.php?id_form=${encodeURIComponent(formId)}`)
            ]);
            
            if (response.ok) {
                const data = await response.json();
                this.showFormDetailsModal(data);
                this.showNotification('Berhasil', `Ditemukan pengiriman dengan ID Form: ${formId}`, 'success');
            } else {
                const errorData = await response.json();
                this.showNotification('Tidak Ditemukan', errorData.error || 'ID Form tidak ditemukan', 'error');
            }
        } catch (error) {
            console.error('Error searching form:', error);
            this.showNotification('Error', 'Gagal mencari data pengiriman', 'error');
        }
    }
    
    showFormDetailsModal(data) {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay';
        modal.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
            background: rgba(0,0,0,0.5); display: flex; align-items: center; 
            justify-content: center; z-index: 1000;
        `;
        
        modal.innerHTML = `
            <div class="modal-content" style="
                background: white; border-radius: 8px; padding: 20px; 
                max-width: 800px; max-height: 80vh; overflow-y: auto;
                box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            ">
                <div class="modal-header" style="
                    display: flex; justify-content: space-between; 
                    align-items: center; margin-bottom: 20px; 
                    border-bottom: 2px solid #eee; padding-bottom: 10px;
                ">
                    <h3 style="margin: 0; color: #333;">📋 Detail Pengiriman - ${data.id_form}</h3>
                    <button onclick="this.closest('.modal-overlay').remove()" style="
                        background: #ff4444; color: white; border: none; 
                        border-radius: 50%; width: 30px; height: 30px; 
                        cursor: pointer; font-size: 16px;
                    ">✕</button>
                </div>
                <div class="modal-body">
                    <div class="shipment-details">
                        <h4 style="color: #444; margin-bottom: 15px;">Informasi Pengiriman</h4>
                        <div style="
                            display: grid; grid-template-columns: 1fr 1fr; 
                            gap: 15px; margin-bottom: 20px; 
                            padding: 15px; background: #f8f9fa; border-radius: 6px;
                        ">
                            <div><strong>ID Form:</strong> ${data.shipment.id_form}</div>
                            <div><strong>No. Dokumen:</strong> ${data.shipment.no_dokumen}</div>
                            <div><strong>No. Polisi:</strong> ${data.shipment.no_polisi}</div>
                            <div><strong>No. Segel:</strong> ${data.shipment.no_segel}</div>
                            <div><strong>Driver:</strong> ${data.shipment.nama_driver}</div>
                            <div><strong>Co-Driver:</strong> ${data.shipment.nama_co_driver || '-'}</div>
                            <div><strong>Staff:</strong> ${data.shipment.nama_staff}</div>
                            <div><strong>Cabang Tujuan:</strong> ${data.shipment.cabang_tujuan}</div>
                        </div>
                        
                        ${data.shipment.catatan_pengiriman ? `
                            <div style="margin-bottom: 20px;">
                                <strong>Catatan Pengiriman:</strong>
                                <div style="background: #e8f4fd; padding: 10px; border-radius: 4px; margin-top: 5px;">
                                    ${data.shipment.catatan_pengiriman}
                                </div>
                            </div>
                        ` : ''}
                        
                        <h4 style="color: #444; margin-bottom: 15px;">Daftar Barang (${data.total_items} item)</h4>
                        <div style="overflow-x: auto;">
                            <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd;">
                                <thead>
                                    <tr style="background: #f1f3f4;">
                                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">No</th>
                                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Nama Barang</th>
                                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">No. Dokumen</th>
                                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Tanggal Kirim</th>
                                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Jumlah</th>
                                        <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Catatan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${data.items.map((item, index) => `
                                        <tr>
                                            <td style="border: 1px solid #ddd; padding: 8px;">${index + 1}</td>
                                            <td style="border: 1px solid #ddd; padding: 8px;">${item.nama_barang}</td>
                                            <td style="border: 1px solid #ddd; padding: 8px;">${item.no_dokumen}</td>
                                            <td style="border: 1px solid #ddd; padding: 8px;">${this.formatDate(item.tanggal_kirim)}</td>
                                            <td style="border: 1px solid #ddd; padding: 8px;">${item.jumlah_barang}</td>
                                            <td style="border: 1px solid #ddd; padding: 8px;">${item.catatan || '-'}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div style="
                    display: flex; justify-content: flex-end; gap: 10px; 
                    margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;
                ">
                    <button onclick="this.closest('.modal-overlay').remove()" style="
                        padding: 8px 16px; border: 1px solid #ddd; 
                        background: white; border-radius: 4px; cursor: pointer;
                    ">Tutup</button>
                    <button onclick="window.print()" style="
                        padding: 8px 16px; background: #007bff; color: white; 
                        border: none; border-radius: 4px; cursor: pointer;
                    ">🖨️ Cetak</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Close modal when clicking outside
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    showNotification(title, message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <strong>${title}</strong><br>
            ${message}
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new DeliveryApp();
    app.renderItems(); // Initial render of items table
});