<?php
// Database configuration for XAMPP
$host = 'localhost';
$dbname = 'delivery_tracking';
$username = 'root';
$password = '';

try {
    // Create database if not exists
    $pdo_temp = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password);
    $pdo_temp->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo_temp->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    
    // Connect to the specific database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Test connection
    $test = $pdo->query("SELECT 1");
    
} catch(PDOException $e) {
    // More detailed error message
    $error_message = "Database connection failed: " . $e->getMessage();
    
    // Log error for debugging
    error_log($error_message);
    
    // User-friendly error display
    echo "<div style='background: #ff6b6b; color: white; padding: 20px; margin: 20px; border-radius: 8px;'>";
    echo "<h3>❌ Koneksi Database Gagal</h3>";
    echo "<p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<h4>Solusi:</h4>";
    echo "<ol>";
    echo "<li>Pastikan MySQL service aktif di XAMPP Control Panel</li>";
    echo "<li>Periksa username dan password database (default: root tanpa password)</li>";
    echo "<li>Pastikan MySQL berjalan di port 3306</li>";
    echo "<li>Coba restart XAMPP</li>";
    echo "</ol>";
    echo "</div>";
    exit();
}
?>