<?php
require_once 'auth.php';

// Perform logout
Auth::logout();

// Redirect to login page
header('Location: login.php?logged_out=1');
exit();
?>